import tkinter as tk
import random

dinero = 0
vidas = 3
nivel = 1

productos = {
    "Lápiz": 10,
    "Hoja": 5,
    "Cuaderno": 20
}

personas = [
    ("👩", "Ana", "Lápiz"),
    ("👨", "Carlos", "Hoja"),
    ("👧", "Sofía", "Cuaderno"),
    ("👦", "Diego", "Lápiz"),
    ("👩", "María", "Cuaderno"),
    ("👨", "Luis", "Hoja")
]

persona_actual = None


def nueva_persona():
    global persona_actual

    persona_actual = random.choice(personas)

    emoji, nombre, producto = persona_actual

    persona.config(text=emoji)
    nombre_persona.config(text=nombre)
    pedido.config(text="Necesito un " + producto)
    mensaje.config(text="🎒 ¡Elige el producto correcto!")


def vender(producto):
    global dinero, vidas, nivel

    if vidas <= 0:
        return

    producto_correcto = persona_actual[2]

    if producto == producto_correcto:

        ganancia = productos[producto]
        dinero += ganancia

        mensaje.config(
            text="✅ ¡Venta correcta! Ganaste Q" + str(ganancia)
        )

        if dinero >= nivel * 50:
            nivel += 1

            mensaje.config(
                text="🎉 ¡SUBISTE AL NIVEL " + str(nivel) + "!"
            )

    else:

        vidas -= 1

        mensaje.config(
            text="❌ Producto equivocado. Perdiste una vida."
        )

        if vidas == 0:

            persona.config(text="😢")
            nombre_persona.config(text="JUEGO TERMINADO")
            pedido.config(text="Te quedaste sin vidas.")

            actualizar()
            return

    actualizar()

    ventana.after(1000, nueva_persona)


def actualizar():

    datos.config(
        text="💰 Dinero: Q" + str(dinero)
        + "     ❤️ Vidas: " + str(vidas)
        + "     ⭐ Nivel: " + str(nivel)
    )


def reiniciar():

    global dinero, vidas, nivel

    dinero = 0
    vidas = 3
    nivel = 1

    actualizar()
    nueva_persona()

    mensaje.config(
        text="🔄 ¡Juego reiniciado!"
    )


# =========================
# VENTANA
# =========================

ventana = tk.Tk()

ventana.title("🎒 La Mochila Vendedora")

# Ventana más alta
ventana.geometry("900x850")

# Se puede maximizar
ventana.resizable(True, True)


# =========================
# TÍTULO
# =========================

titulo = tk.Label(
    ventana,
    text="🎒 LA MOCHILA VENDEDORA",
    font=("Arial", 28, "bold")
)

titulo.pack(pady=10)


# =========================
# DATOS
# =========================

datos = tk.Label(
    ventana,
    text="",
    font=("Arial", 16, "bold")
)

datos.pack(pady=5)


# =========================
# PERSONA
# =========================

persona = tk.Label(
    ventana,
    text="👩",
    font=("Arial", 70)
)

persona.pack(pady=5)


# =========================
# NOMBRE
# =========================

nombre_persona = tk.Label(
    ventana,
    text="",
    font=("Arial", 20, "bold")
)

nombre_persona.pack()


# =========================
# PEDIDO
# =========================

pedido = tk.Label(
    ventana,
    text="",
    font=("Arial", 18)
)

pedido.pack(pady=5)


# =========================
# MENSAJE
# =========================

mensaje = tk.Label(
    ventana,
    text="",
    font=("Arial", 15)
)

mensaje.pack(pady=5)


# =========================
# BOTONES
# =========================

boton_lapiz = tk.Button(
    ventana,
    text="✏️ LÁPIZ  Q10",
    font=("Arial", 14, "bold"),
    width=20,
    height=2,
    command=lambda: vender("Lápiz")
)

boton_lapiz.pack(pady=4)


boton_hoja = tk.Button(
    ventana,
    text="📄 HOJA  Q5",
    font=("Arial", 14, "bold"),
    width=20,
    height=2,
    command=lambda: vender("Hoja")
)

boton_hoja.pack(pady=4)


boton_cuaderno = tk.Button(
    ventana,
    text="📓 CUADERNO  Q20",
    font=("Arial", 14, "bold"),
    width=20,
    height=2,
    command=lambda: vender("Cuaderno")
)

boton_cuaderno.pack(pady=4)


# =========================
# REINICIAR
# =========================

boton_reiniciar = tk.Button(
    ventana,
    text="🔄 REINICIAR JUEGO",
    font=("Arial", 14, "bold"),
    width=20,
    height=2,
    command=reiniciar
)

boton_reiniciar.pack(pady=10)


# =========================
# INICIAR
# =========================

actualizar()
nueva_persona()

ventana.mainloop()
